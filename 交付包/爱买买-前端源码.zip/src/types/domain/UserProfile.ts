/**
 * 域模型：用户资料（UserProfile）
 *
 * 用途：
 * - 我的页身份名片（等级/成长值/积分/头像框）、发帖/评论作者信息
 */
import { AvatarFrame } from './Me';

export type UserProfile = {
  id: string;
  name: string;
  avatar: string;
  level: string;
  levelProgress: number;
  growthPoints: number;
  nextLevelPoints: number;
  points: number;
  location: string;
  interests?: string[];
  avatarFrame?: AvatarFrame;
};
